/**
 * Supabase configuration
 */

const { createClient } = require('@supabase/supabase-js');
const { SUPABASE_URL, SUPABASE_KEY } = require('./env');

// Create Supabase client
const supabaseClient = createClient(SUPABASE_URL, SUPABASE_KEY);

module.exports = supabaseClient;
