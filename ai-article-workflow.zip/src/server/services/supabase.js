/**
 * Supabase service for data and image storage
 */

const supabaseClient = require('../config/supabase');

class SupabaseService {
  /**
   * Save article data to Supabase
   * @param {Object} articleData - Article data to save
   * @returns {Promise<Object>} - Saved article data
   */
  async saveArticle(articleData) {
    try {
      const { data, error } = await supabaseClient
        .from('articles')
        .insert(articleData)
        .select();

      if (error) throw error;
      return data[0];
    } catch (error) {
      console.error('Error saving article:', error);
      throw error;
    }
  }

  /**
   * Save article version to Supabase
   * @param {Object} versionData - Version data to save
   * @returns {Promise<Object>} - Saved version data
   */
  async saveArticleVersion(versionData) {
    try {
      const { data, error } = await supabaseClient
        .from('article_versions')
        .insert(versionData)
        .select();

      if (error) throw error;
      return data[0];
    } catch (error) {
      console.error('Error saving article version:', error);
      throw error;
    }
  }

  /**
   * Save prompt to Supabase
   * @param {Object} promptData - Prompt data to save
   * @returns {Promise<Object>} - Saved prompt data
   */
  async savePrompt(promptData) {
    try {
      const { data, error } = await supabaseClient
        .from('prompts')
        .insert(promptData)
        .select();

      if (error) throw error;
      return data[0];
    } catch (error) {
      console.error('Error saving prompt:', error);
      throw error;
    }
  }

  /**
   * Get prompts by AI component
   * @param {string} aiComponent - AI component to get prompts for
   * @param {string} userId - User ID (optional)
   * @returns {Promise<Array>} - Array of prompts
   */
  async getPromptsByComponent(aiComponent, userId = null) {
    try {
      let query = supabaseClient
        .from('prompts')
        .select('*')
        .eq('ai_component', aiComponent);

      if (userId) {
        query = query.or(`user_id.eq.${userId},is_default.eq.true`);
      } else {
        query = query.eq('is_default', true);
      }

      const { data, error } = await query;

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error getting prompts:', error);
      throw error;
    }
  }

  /**
   * Upload image to Supabase Storage
   * @param {string} imageUrl - URL of the image to upload
   * @param {string} articleId - ID of the article
   * @param {string} prompt - Image generation prompt
   * @returns {Promise<Object>} - Saved image data
   */
  async saveImage(imageUrl, articleId, prompt) {
    try {
      // First, fetch the image from the URL
      const response = await fetch(imageUrl);
      const imageBlob = await response.blob();
      
      // Generate a unique filename
      const filename = `${articleId}_${Date.now()}.png`;
      
      // Upload to Supabase Storage
      const { data: uploadData, error: uploadError } = await supabaseClient
        .storage
        .from('images')
        .upload(filename, imageBlob);
      
      if (uploadError) throw uploadError;
      
      // Get the public URL
      const { data: { publicUrl } } = supabaseClient
        .storage
        .from('images')
        .getPublicUrl(filename);
      
      // Save image metadata to the database
      const { data: imageData, error: imageError } = await supabaseClient
        .from('images')
        .insert({
          article_id: articleId,
          prompt,
          url: publicUrl,
          created_at: new Date().toISOString()
        })
        .select();
      
      if (imageError) throw imageError;
      return imageData[0];
    } catch (error) {
      console.error('Error saving image:', error);
      throw error;
    }
  }

  /**
   * Get articles by user ID
   * @param {string} userId - User ID
   * @returns {Promise<Array>} - Array of articles
   */
  async getArticlesByUser(userId) {
    try {
      const { data, error } = await supabaseClient
        .from('articles')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error getting articles:', error);
      throw error;
    }
  }

  /**
   * Get article by ID with latest version
   * @param {string} articleId - Article ID
   * @returns {Promise<Object>} - Article data with latest version
   */
  async getArticleWithLatestVersion(articleId) {
    try {
      // Get the article
      const { data: article, error: articleError } = await supabaseClient
        .from('articles')
        .select('*')
        .eq('id', articleId)
        .single();

      if (articleError) throw articleError;

      // Get the latest version
      const { data: versions, error: versionsError } = await supabaseClient
        .from('article_versions')
        .select('*')
        .eq('article_id', articleId)
        .order('version_number', { ascending: false })
        .limit(1);

      if (versionsError) throw versionsError;

      // Get associated images
      const { data: images, error: imagesError } = await supabaseClient
        .from('images')
        .select('*')
        .eq('article_id', articleId);

      if (imagesError) throw imagesError;

      return {
        ...article,
        latest_version: versions.length > 0 ? versions[0] : null,
        images: images
      };
    } catch (error) {
      console.error('Error getting article with latest version:', error);
      throw error;
    }
  }
}

module.exports = SupabaseService;
