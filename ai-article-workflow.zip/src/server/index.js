/**
 * Main server entry point
 */

const express = require('express');
const cors = require('cors');
const { PORT } = require('./config/env');

// Create Express app
const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// API routes
app.use('/api/title', require('./api/title'));
app.use('/api/research', require('./api/research'));
app.use('/api/outline', require('./api/outline'));
app.use('/api/draft', require('./api/draft'));
app.use('/api/critique', require('./api/critique'));
app.use('/api/revision', require('./api/revision'));
app.use('/api/image', require('./api/image'));
app.use('/api/html', require('./api/html'));

// Serve static files from the 'public' directory
app.use(express.static('public'));

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Something went wrong!' });
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

module.exports = app;
