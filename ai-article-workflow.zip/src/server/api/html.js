/**
 * HTML formatting API endpoint
 */

const express = require('express');
const router = express.Router();
const OpenAIService = require('../services/openai');
const SupabaseService = require('../services/supabase');

// POST /api/html
router.post('/', async (req, res) => {
  try {
    const { article, imageUrl, prompt, apiKey } = req.body;
    
    if (!article || !imageUrl) {
      return res.status(400).json({ error: 'Article content and image URL are required' });
    }
    
    const openaiService = new OpenAIService(apiKey);
    const html = await openaiService.formatHTML(article, imageUrl, prompt);
    
    res.json({ html });
  } catch (error) {
    console.error('Error in HTML formatting endpoint:', error);
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
