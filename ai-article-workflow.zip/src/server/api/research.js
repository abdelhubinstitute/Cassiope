/**
 * Research API endpoint
 */

const express = require('express');
const router = express.Router();
const PerplexityService = require('../services/perplexity');
const SupabaseService = require('../services/supabase');

// POST /api/research
router.post('/', async (req, res) => {
  try {
    const { title, prompt, apiKey } = req.body;
    
    if (!title) {
      return res.status(400).json({ error: 'Title is required' });
    }
    
    const perplexityService = new PerplexityService(apiKey);
    const research = await perplexityService.performResearch(title, prompt);
    
    res.json({ research });
  } catch (error) {
    console.error('Error in research endpoint:', error);
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
