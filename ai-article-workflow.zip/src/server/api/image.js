/**
 * Image generation API endpoint
 */

const express = require('express');
const router = express.Router();
const OpenAIService = require('../services/openai');
const SupabaseService = require('../services/supabase');

// POST /api/image
router.post('/', async (req, res) => {
  try {
    const { article, prompt, apiKey, articleId } = req.body;
    
    if (!article) {
      return res.status(400).json({ error: 'Article content is required' });
    }
    
    const openaiService = new OpenAIService(apiKey);
    
    // First, generate the image prompt if not provided
    const imagePrompt = prompt || await openaiService.generateImagePrompt(article);
    
    // Then, generate the image
    const imageUrl = await openaiService.generateImage(imagePrompt);
    
    // If articleId is provided, save the image to Supabase
    let savedImage = null;
    if (articleId) {
      const supabaseService = new SupabaseService();
      savedImage = await supabaseService.saveImage(imageUrl, articleId, imagePrompt);
    }
    
    res.json({ 
      imageUrl,
      imagePrompt,
      savedImage
    });
  } catch (error) {
    console.error('Error in image generation endpoint:', error);
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
